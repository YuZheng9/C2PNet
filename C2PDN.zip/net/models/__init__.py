import sys,os
dir=os.path.abspath(os.path.dirname(__file__))
sys.path.append(dir)
from C2PDN import C2PDN
